import React, { useState } from 'react';

const App: React.FC = () => {

 const inputRef = useRef<HTMLInputElement>(null);

  if (inputRef.current != null) {
    inputRef.current.value = 'anish';
  }

  const anish: string = '';
  useEffect(() => {
    console.log();
    return () => {

    }
  }, [anish]);

  const [msg, setMsg] = useState<string>('Test');

  const onChnage = (text: string) => {
    setMsg(text);
  }

  return (<>
    {msg}
    <ButtonComponent onChnage={onChnage} />

  </>);
}

export default App;

interface Props {
  onChnage: (text: string) => void
}


const ButtonComponent: React.FC<Props> = ({ onChnage }) => {
  let value: string = '';
  const onChnageHandler = (text: string) => {
    console.log(text);
    value = text;
  }
  return (
    <>
      <input onChange={(e) => onChnageHandler(e.target.value)} />
      <button type='button' onClick={() => onChnage(value)}>Suubmit </button>
    </>
  );
}


//https://www.geeksforgeeks.org/how-to-add-theme-to-your-react-app/