import { Button as MuiButton } from "@mui/material";

interface IBProps extends ButtonProps {
  label?: string,
}

const StyledButton = styled(MuiButton)<IBProps>(() => ({
  height: "10px",
}
)
)

export const Button = ({ label }: IBProps) => {
  return (
    <StyledButton>{label}</StyledButton>
  );
}

//https://www.geeksforgeeks.org/how-to-set-flexbox-having-unequal-width-of-elements-using-css/

// themse at last https://mui.com/material-ui/customization/typography/

// override theme components https://mui.com/material-ui/customization/theme-components/

//centre align https://www.w3schools.com/css/tryit.asp?filename=trycss_align_container

//aso see app.css

// use .centre class