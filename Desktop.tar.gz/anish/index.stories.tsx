import type { Meta, StoryObj } from "@storybook/react";
import TablePagination from "./index";
const meta = {
  title: "Molecules/TablePagination",
  component: TablePagination,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {},
} satisfies Meta<typeof TablePagination>;

export default meta;

type Story = StoryObj<typeof meta>;

export const CandidatesTablePaginationMolecule: Story = {
  args: {
    currentPage: 1,
    itemsPerPage: 10,
    rows: 100,
    totalPages: 10,
    
  },
};