package com.checker.model;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "NOTICE")
public class Notice {

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "CREATED_AT")
	private Timestamp createdAt;

	@Column(name = "AUTO_SEND")
	private int autoSend;

	@OneToMany(mappedBy = "catalog", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@Builder.Default
	private Set<Charge> charges = new HashSet<>();

}
