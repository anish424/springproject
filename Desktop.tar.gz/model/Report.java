package com.checker.model;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "REPORT")
public class Report {

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "REPORT_STATUS")
	private String reportStatus;

	@Column(name = "PACKAGE")
	private String reportPackage;

	@Column(name = "CREATED_AT")
	private Timestamp createdAt;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "NOTICE_ID", referencedColumnName = "ID")
	private Notice notice;

	@Column(name = "ADJUDICATION")
	private String adjudication;

	@ManyToMany
	@JoinTable(name = "REPORT_SEARCH_TYPE_MAPPER", joinColumns = @JoinColumn(name = "REPORT_ID"), inverseJoinColumns = @JoinColumn(name = "SEARCH_TYPE_ID"))
	private Set<SearchType> searchTypes;

}
