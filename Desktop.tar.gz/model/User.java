package com.checker.model;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "USER")
public class User {

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "MOBILE_NO")
	private String mobileNo;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "DOB")
	private Date dob;

	@Column(name = "CREATED_AT")
	private Timestamp createdAt;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "REPORT_ID", referencedColumnName = "ID")
	private Report report;

	@OneToOne(optional = false, mappedBy = "user", cascade = CascadeType.ALL)
	private Credential credential;

}
