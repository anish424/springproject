package com.checker.service;

import com.checker.dto.EmailDetails;

public interface EmailService {

	// Method
	// To send a simple email
	String sendSimpleMail(EmailDetails details);

}