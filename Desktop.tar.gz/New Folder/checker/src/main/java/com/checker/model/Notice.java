package com.checker.model;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity
@Table(name = "NOTICE")
public class Notice {

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "NOTICE_CREATE_DATE",nullable = false)
	private Timestamp createDate;

	@Column(name = "NOTICE_AUTO_SEND_DURATION")
	private int autoSendDuration;

	@OneToMany(mappedBy = "notice", cascade = CascadeType.ALL)
	@Builder.Default
	private Set<Charge> charges = new HashSet<>();

}
