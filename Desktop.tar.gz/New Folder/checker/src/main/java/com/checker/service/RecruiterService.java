package com.checker.service;

import com.checker.dto.JwtRequest;

public interface RecruiterService {
	
	public void signup(JwtRequest request) throws Exception;

}
