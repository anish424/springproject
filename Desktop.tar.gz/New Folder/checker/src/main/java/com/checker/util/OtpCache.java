package com.checker.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import lombok.Data;

@Data
public class OtpCache {
	private String otp;
	private long createdTime;
	private static Map<String, OtpCache> otpCache = new HashMap<>();

	public static String getOtp(String username) throws Exception {
		OtpCache otp = otpCache.get(username);
		if (otp == null)
			throw new Exception("No otp generated for this user");
		otp.isOtpValid();
		return otp.getOtp();
	}

	public static String generateOtp(String username) {
		long otp =new Random().nextInt(900000) + 100000;
		otpCache.put(username, new OtpCache(String.valueOf(otp), System.currentTimeMillis()));
		return otpCache.get(username).getOtp();
	}

	private void isOtpValid() throws Exception {
		if (System.currentTimeMillis() - createdTime > 240000)
			throw new Exception(" otp expired");
	}

	public OtpCache(String otp, long createdTime) {
		super();
		this.otp = otp;
		this.createdTime = createdTime;
	}
}
