package com.checker.service.impl;

import java.sql.SQLException;
import java.sql.Timestamp;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.checker.dto.JwtRequest;
import com.checker.model.Recruiter;
import com.checker.repository.RecruiterRepository;
import com.checker.service.RecruiterService;

@Service
public class RecruiterServiceImpl implements RecruiterService {

	@Autowired
	private RecruiterRepository recruiterRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public void signup(JwtRequest request) throws Exception {
		try {
			Recruiter entity = convertToEntity(request);
			recruiterRepo.save(entity);
		} catch (Exception e) {
			throw new Exception("Signup failed, please try again later");
		}
	}

	private Recruiter convertToEntity(JwtRequest request) {
		Recruiter entity = modelMapper.map(request, Recruiter.class);
		entity.setCreateDate(new Timestamp(System.currentTimeMillis()));
		entity.setPassword(passwordEncoder.encode(request.getPassword()));
		entity.setActive(true);
		return entity;
	}

}
