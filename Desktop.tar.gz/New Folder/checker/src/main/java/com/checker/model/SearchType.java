package com.checker.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.json.simple.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "SEARCH_TYPE")
public class SearchType {

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "SEARCH_NAME")
	private String name;

	@Transient
	private String status;

	@Transient
	private Timestamp createdDate;

	public static SearchType valueOf(String value) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(value, SearchType.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public String toString() {
		JSONObject data = new JSONObject();
		data.put("id", this.getId());
		data.put("name", this.getName());
		data.put("status", this.getStatus());
		data.put("createdDate", this.getCreatedDate());
		return data.toJSONString();
	}

}
