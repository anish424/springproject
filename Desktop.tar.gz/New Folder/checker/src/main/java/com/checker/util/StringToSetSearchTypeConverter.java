package com.checker.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.checker.model.SearchType;

@Converter
public class StringToSetSearchTypeConverter implements AttributeConverter<Set<SearchType>, String> {

	@Override
	public String convertToDatabaseColumn(Set<SearchType> searchTypes) {
		if (!Optional.ofNullable(searchTypes).isPresent())
			return "";
		return searchTypes.stream().map(SearchType::toString).collect(Collectors.joining(","));
	}

	@Override
	public Set<SearchType> convertToEntityAttribute(String joined) {
		if (!Optional.ofNullable(joined).filter(s -> !s.isEmpty()).isPresent())
			return new HashSet<>();
		return
		Arrays.asList(joined.split(",")).stream().map(SearchType::valueOf).collect(Collectors.toSet());

	}

}