package com.checker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.checker.dto.EmailDetails;
import com.checker.dto.JwtRequest;
import com.checker.service.EmailService;
import com.checker.service.RecruiterService;
import com.checker.util.OtpCache;

@RestController
public class RecruiterController {

	@Autowired
	private RecruiterService recruiterService;

	@Autowired
	private EmailService emailService;

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ResponseEntity<String> signUp(@RequestBody JwtRequest request) throws Exception {
		recruiterService.signup(request);
		return ResponseEntity.ok().body("Signup successful");
	}

	@RequestMapping(value = "/otp", method = RequestMethod.GET)
	public ResponseEntity<String> sendOtp(@RequestParam String username) throws Exception {
		String otp = OtpCache.generateOtp(username);
		EmailDetails details = new EmailDetails();
		details.setMsgBody("Otp: " + otp + " ,valid for 4 minutes");
		details.setRecipient(username);
		details.setSubject("One Time Password (OTP) for your login");
		emailService.sendSimpleMail(details);
		return ResponseEntity.ok().body("Otp sent successfully");
	}

}
