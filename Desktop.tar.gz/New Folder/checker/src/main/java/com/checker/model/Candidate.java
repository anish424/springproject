package com.checker.model;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CANDIDATE")
public class Candidate {

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "CANDIDATE_NAME", nullable = false)
	private String name;

	@Column(name = "CANDIDATE_MOBILE_NO")
	private String mobileNo;

	@Column(name = "CANDIDATe_EMAIL", nullable = false)
	private String email;

	@Column(name = "CANDIDATE_DOB", nullable = false)
	private Date dob;

	@Column(name = "CANDIDATE_CREATE_DATE", nullable = false)
	private Timestamp createdDate;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "REPORT_ID", referencedColumnName = "ID")
	private Report report;

}
