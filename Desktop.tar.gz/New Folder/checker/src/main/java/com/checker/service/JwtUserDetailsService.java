package com.checker.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.checker.model.Recruiter;
import com.checker.repository.RecruiterRepository;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private RecruiterRepository recruiterRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Recruiter user = recruiterRepository.findByUsername(username);

		if (user.getUsername().equals(username)) {
			return user;
		} else {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
	}
}
