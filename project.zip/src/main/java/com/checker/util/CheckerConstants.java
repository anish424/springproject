package com.checker.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CheckerConstants {
	public static final String DATE_FORMAT = "MM/dd/yyyy";
	public static final String ADJUDICATION = "adjudication";
}
