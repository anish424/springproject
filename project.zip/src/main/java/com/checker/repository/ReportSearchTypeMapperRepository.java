package com.checker.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.checker.model.ReportSearchTypeMapper;

public interface ReportSearchTypeMapperRepository  extends JpaRepository<ReportSearchTypeMapper, Integer> {

}
