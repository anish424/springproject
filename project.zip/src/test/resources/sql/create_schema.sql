create schema IF NOT EXISTS CHECKER;
