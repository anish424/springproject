package com.bookstore.entity;

import java.sql.Date;

import com.bookstore.model.Book;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;

@Entity(name = "Book")
@lombok.Data
public class BookEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SequenceBookEntityId")
	@SequenceGenerator(name = "SequenceBookEntityId", sequenceName = "BOOK_ENTITY_SEQ")
	private long id;

	@Column
	private String name;

	@Column
	private String description;

	@Column
	private double price;

	@Column
	private Date publishDate;

	@JoinColumn(name = "AuthorEntity_id")
	@ManyToOne(cascade = CascadeType.PERSIST)
	private AuthorEnity author;

	public BookEntity(Book book) {
		this.name=book.getName();
		this.description=book.getDescription();
		this.price=book.getPrice();
		AuthorEnity entity = new AuthorEnity(book.getAuthor(), book.getAuthorRegistrationNo());
		this.author = entity;
	}

	public BookEntity() {
		// TODO Auto-generated constructor stub
	}

	public BookEntity(String name, String description, double price, Date publishDate, AuthorEnity author) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
		this.publishDate = publishDate;
		this.author = author;
	}

}
