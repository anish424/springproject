package com.bookstore.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;

@lombok.Data
@Entity(name = "Author")
public class AuthorEnity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SequenceAuthorEntityId")
	@SequenceGenerator(name = "SequenceAuthorEntityId", sequenceName = "AUTHOR_ENTITY_SEQ")
	private long id;

	@Column
	private String name;

	@Column
	private String registrationNo;

	public AuthorEnity(String name, String registrationNo) {
		super();
		this.name = name;
		this.registrationNo = registrationNo;
	}

	public AuthorEnity() {
		super();
	}
	
}
