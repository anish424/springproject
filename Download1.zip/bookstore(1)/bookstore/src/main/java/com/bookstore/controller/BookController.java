package com.bookstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bookstore.model.Book;
import com.bookstore.service.BookService;
import com.bookstore.util.CsvHelper;

@RestController
public class BookController {

	@Autowired
	private BookService bookService;

	@GetMapping(path = "/books/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<?> getBooks() {
		return ResponseEntity.status(HttpStatus.OK)
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "book.csv")
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE)
				.body(bookService.getAllBooks().readAllBytes());
	}

	@PostMapping("/books/upload")
	public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
		String message = "";

		if (CsvHelper.hasCSVFormat(file)) {
			try {
				bookService.saveBooks(file);

				message = "Uploaded the file successfully: " + file.getOriginalFilename();
				return ResponseEntity.status(HttpStatus.OK).body(message);
			} catch (Exception e) {
				message = "Could not upload the file: " + file.getOriginalFilename() + "!";
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Not a CSV file");
		}
	}

	@PostMapping("/books")
	public ResponseEntity<String> save(@RequestBody Book book) {
		try {
			bookService.saveBook(book);
			return ResponseEntity.status(HttpStatus.OK).body("saved");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("failed");
		}
	}

}
