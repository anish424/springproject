package com.bookstore.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bookstore.entity.BookEntity;
import com.bookstore.model.Book;
import com.bookstore.respository.BookRepository;
import com.bookstore.util.CsvHelper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepo;

	@Override

	public String saveBooks(MultipartFile file) {
		try {
			List<BookEntity> bookentities = CsvHelper.csvToTBooks(file.getInputStream());
			bookRepo.saveAll(bookentities);
			return "Books saved sucessfully";
		} catch (Exception e) {
			log.error("Failed to save books", e);
			return "Failed to save books";
		}
	}

	@Override
	public ByteArrayInputStream getAllBooks() {
		List<BookEntity> bookentities = bookRepo.findAll();
		return CsvHelper.writeDataToCsv(bookentities);
	}
	
	@Override
	public void saveBook(Book book) {
		BookEntity entity = new BookEntity(book);
		bookRepo.save(entity);
	}

}
