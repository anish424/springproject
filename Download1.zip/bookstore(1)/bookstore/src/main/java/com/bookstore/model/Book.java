package com.bookstore.model;

import java.io.Serializable;
import java.util.Date;

@lombok.Data
public class Book implements Serializable {

	private static final long serialVersionUID = 5543490049965016411L;
	private String name;
	private String description;
	private String author;
	private double price;
	private Date publishedDate;
	private String authorRegistrationNo;
}
