package com.bookstore.service;

import java.io.ByteArrayInputStream;

import org.springframework.web.multipart.MultipartFile;

import com.bookstore.model.Book;

public interface BookService {

	public String saveBooks(MultipartFile file);

	public ByteArrayInputStream getAllBooks();
	
	public void saveBook(Book book);

}
