package com.bookstore.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.springframework.web.multipart.MultipartFile;

import com.bookstore.entity.AuthorEnity;
import com.bookstore.entity.BookEntity;

public class CsvHelper {

	private static final String[] HEADERS = { "Name", "Description", "Price", "Author", "Published Date",
			"Author Registration No" };
	private static final CSVFormat FORMAT = CSVFormat.DEFAULT.withHeader(HEADERS);
	public static String TYPE = "text/csv";

	public static ByteArrayInputStream writeDataToCsv(final List<BookEntity> books) {
		try (final ByteArrayOutputStream stream = new ByteArrayOutputStream();
				final CSVPrinter printer = new CSVPrinter(new PrintWriter(stream), FORMAT)) {
			return new ByteArrayInputStream(stream.toByteArray());
		} catch (final IOException e) {
			throw new RuntimeException("Csv writing error: " + e.getMessage());
		}
	}

	public static List<BookEntity> csvToTBooks(InputStream is) throws NumberFormatException, ParseException {
		try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				CSVParser csvParser = new CSVParser(fileReader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

			List<BookEntity> books = new ArrayList<BookEntity>();

			Iterable<CSVRecord> csvRecords = csvParser.getRecords();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			for (CSVRecord csvRecord : csvRecords) {
				BookEntity tutorial = new BookEntity(csvRecord.get("Name"), csvRecord.get("Description"),
						Double.parseDouble(csvRecord.get("Price")),
						new java.sql.Date(formatter.parse(csvRecord.get("Published Date")).getTime()),
						new AuthorEnity(csvRecord.get("Author"), csvRecord.get("Author Registration No")));

				books.add(tutorial);
			}

			return books;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
		}
	}

	public static boolean hasCSVFormat(MultipartFile file) {

		if (!TYPE.equals(file.getContentType())) {
			return false;
		}

		return true;
	}

}
