package com.codurance.training.tasks

class Task(val id: Long, val description: String, var isDone: Boolean)
