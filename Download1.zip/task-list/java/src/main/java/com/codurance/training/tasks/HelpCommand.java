package com.codurance.training.tasks;

public class HelpCommand implements Command {

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	@Override
	public void execute(String commandLine) {

		taskList.getOut().println("Commands:");
		taskList.getOut().println("  show");
		taskList.getOut().println("  view by project");
		taskList.getOut().println("  add project <project name>");
		taskList.getOut().println("  add task <project name> <task description> ,<task Id (optional)>");
		taskList.getOut().println("  check <task ID>");
		taskList.getOut().println("  uncheck <task ID>");
		taskList.getOut().println("  deadline <task ID> <date in MM/dd/yyyy>");
		taskList.getOut().println("  delete <task ID>");
		taskList.getOut().println("  today");
		taskList.getOut().println("  view by deadline");
		taskList.getOut().println();

	}

}
