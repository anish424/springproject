package com.codurance.training.tasks;

public interface Command {
	
	public void execute(String commandLine);
	public void setTaskList(TaskList taskList);

}
