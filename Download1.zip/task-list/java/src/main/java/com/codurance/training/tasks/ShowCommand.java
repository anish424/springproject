package com.codurance.training.tasks;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShowCommand implements Command {

	private String condition;
	private static Map<String, Function> map = new HashMap<>();

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	public ShowCommand(String condition) {
		this.condition = condition;
		populateMap();
	}

	public ShowCommand() {
		super();
		populateMap();
	}

	private void populateMap() {
		Function<Task, TaskList> show = this::show;
		Function<Task, TaskList> showDeadline = this::showDueToday;
		map.put("show", show);
		map.put("view by project", show);
		map.put("today", showDeadline);
	}

	@Override
	public void execute(String command) {

		for (Map.Entry<String, List<Task>> project : taskList.getTasks().entrySet()) {
			taskList.getOut().println(project.getKey());
			for (Task task : project.getValue()) {
				map.get(condition).show(task, taskList);
			}
			taskList.getOut().println();
		}

	}

	private void show(Task task, TaskList taskList) {
		taskList.getOut().printf("    [%c] %s: %s%n", (task.isDone() ? 'x' : ' '), task.getId(), task.getDescription());
	}

	private void showDueToday(Task task, TaskList taskList) {
		Date date = new Date(System.currentTimeMillis());
		Date dueDate = task.getDeadline();
		if (compare(date, dueDate) == 0) {
			show(task, taskList);
		}
	}

	public static int compare(Date d1, Date d2) {
		if(d2==null)
			return -1;
		if (d1.getYear() != d2.getYear())
			return d1.getYear() - d2.getYear();
		if (d1.getMonth() != d2.getMonth())
			return d1.getMonth() - d2.getMonth();
		return d1.getDate() - d2.getDate();
	}

}

interface Function<T, R> {
	void show(T t, R r);
}
