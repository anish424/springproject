package com.codurance.training.tasks;

import java.util.regex.Pattern;

public class InputValidator {

	private static Pattern pattern = Pattern.compile("[^a-z0-9]", Pattern.CASE_INSENSITIVE);

	// Validate that input has no special characters and no spaces
	public static boolean validateInput(String value) {
		if (value == null)
			return false;
		return pattern.matcher(value.trim()).find() || value.contains(" ");
	}

}
