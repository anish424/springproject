package com.codurance.training.tasks;

import java.util.HashMap;
import java.util.Map;

public class CommandExecutor {

	private static Map<String, Command> map = new HashMap<>();
	static {
		map.put("show", new ShowCommand("show"));
		map.put("show", new ShowCommand("view by project"));
		map.put("add", new AddCommand());
		map.put("deadline", new DeadlineCommand());
		map.put("today", new ShowCommand("today"));
		map.put("check", new CheckCommand(true));
		map.put("uncheck", new CheckCommand(false));
		map.put("delete", new DeleteCommand());
		map.put("view by deadline", new ShowByDeadLineCommand());
		map.put("help", new HelpCommand());
		map.put("error", new ErrorCommand());
	}

	public static void executeCommand(String commandLine, TaskList taskList) {
		String[] commandRest = commandLine.split(" ", 2);
		String command = commandRest[0];
		if (map.containsKey(command)) {
			Command comand = map.get(command);
			comand.setTaskList(taskList);
			comand.execute(commandRest.length == 2 ? commandRest[1] : commandRest[0]);
		}else if(map.containsKey(commandLine)) {
			Command comand = map.get(commandLine);
			comand.setTaskList(taskList);
			comand.execute(command);
		}else {
			map.get("error").execute(command);
		}
	}

}
