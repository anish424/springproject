package com.codurance.training.tasks;

import java.util.List;
import java.util.ListIterator;
import java.util.Map;

public class DeleteCommand implements Command {

	private TaskList taskList;

	@Override
	public void execute(String commandLine) {

		for (Map.Entry<String, List<Task>> project : taskList.getTasks().entrySet()) {
			ListIterator<Task> iterator = project.getValue().listIterator();
			while(iterator.hasNext()) {
				Task task = iterator.next();
				if (task.getId().equals(commandLine)) {
					iterator.remove();
					return;
				}
			}
		}
		taskList.getOut().printf("Could not find a task with an ID of %s.", commandLine);
		taskList.getOut().println();

	}

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

}
