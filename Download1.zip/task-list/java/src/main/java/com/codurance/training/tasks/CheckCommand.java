package com.codurance.training.tasks;

import java.util.List;
import java.util.Map;

public class CheckCommand implements Command {

	private boolean check;

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	public CheckCommand(boolean check) {
		super();
		this.check = check;
	}

	@Override
	public void execute(String commandLine) {

		for (Map.Entry<String, List<Task>> project : taskList.getTasks().entrySet()) {
			for (Task task : project.getValue()) {
				if (task.getId().equals(commandLine)) {
					task.setDone(check);
					return;
				}
			}
		}
		taskList.getOut().printf("Could not find a task with an ID of %s.", commandLine);
		taskList.getOut().println();
	}

}
