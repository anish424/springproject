package com.codurance.training.tasks;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class TaskList {
	public static final String QUIT = "quit";

	private final Map<String, List<Task>> tasks = new LinkedHashMap<>();
	private final BufferedReader in;
	private final PrintWriter out;

	 private AtomicLong lastId = new AtomicLong(0);

	public AtomicLong getLastId() {
		return lastId;
	}

	public Map<String, List<Task>> getTasks() {
		return tasks;
	}

	public BufferedReader getIn() {
		return in;
	}

	public PrintWriter getOut() {
		return out;
	}

	public TaskList(BufferedReader reader, PrintWriter writer) {
		this.in = reader;
		this.out = writer;
	}

}
