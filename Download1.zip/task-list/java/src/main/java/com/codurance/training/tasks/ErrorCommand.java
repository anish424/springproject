package com.codurance.training.tasks;

public class ErrorCommand implements Command {

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	@Override
	public void execute(String commandLine) {
		taskList.getOut().printf("I don't know what the command \"%s\" is.", commandLine);
		taskList.getOut().println();
	}

}
