package com.codurance.training.tasks;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class DeadlineCommand implements Command {

	private static String dateFormat = "MM/dd/yyyy";

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	@Override
	public void execute(String commandLine) {
		String[] subcommandRest = commandLine.split(" ", 2);
		String id = subcommandRest[0];
		String dateStr = subcommandRest[1];
		Task task = validateId(id);
		Date deadline = validateDate(dateStr);
		if (task == null) {
			taskList.getOut().printf("invalid task id:  \"%s\"", id);
		} else if (deadline == null) {
			taskList.getOut().printf("invalid date format, required date format: \"%s\"" + dateFormat);
		} else {
			task.setDeadline(deadline);
		}

	}

	private Task validateId(String id) {
		for (Map.Entry<String, List<Task>> project : taskList.getTasks().entrySet()) {
			for (Task task : project.getValue()) {
				if (task.getId().equals(id))
					return task;
			}
		}
		return null;
	}

	private Date validateDate(String dateStr) {
		DateFormat sdf = new SimpleDateFormat(dateFormat);
		sdf.setLenient(false);
		try {
			return sdf.parse(dateStr);
		} catch (ParseException e) {
			return null;
		}
	}

}
