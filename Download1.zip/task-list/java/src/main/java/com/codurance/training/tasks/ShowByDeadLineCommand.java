package com.codurance.training.tasks;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ShowByDeadLineCommand implements Command {

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	@Override
	public void execute(String commandLine) {
		Map<Date, List<Task>> deadlineMap = new HashMap<>();
		for (Map.Entry<String, List<Task>> project : taskList.getTasks().entrySet()) {
			for (Task task : project.getValue()) {

				if (deadlineMap.containsKey(task.getDeadline())) {
					deadlineMap.get(task.getDeadline()).add(task);
				} else {
					deadlineMap.put(task.getDeadline(), new ArrayList<>());
					deadlineMap.get(task.getDeadline()).add(task);
				}
			}
		}
		showByDeadline(deadlineMap);
	}

	private void showByDeadline(Map<Date, List<Task>> deadlineMap) {
		for (Entry<Date, List<Task>> entry : deadlineMap.entrySet()) {
			taskList.getOut().println(entry.getKey() == null ? "No deadline set" : entry.getKey());
			for (Task task : entry.getValue()) {
				show(task, taskList);
			}
			taskList.getOut().println();
		}
	}

	private void show(Task task, TaskList taskList) {
		taskList.getOut().printf("    [%c] %s: %s%n", (task.isDone() ? 'x' : ' '), task.getId(), task.getDescription());
	}

}
