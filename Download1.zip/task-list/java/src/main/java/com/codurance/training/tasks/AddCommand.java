package com.codurance.training.tasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AddCommand implements Command {

	private TaskList taskList;

	@Override
	public void setTaskList(TaskList taskList) {
		this.taskList = taskList;
	}

	@Override
	public void execute(String commandLine) {

		String[] subcommandRest = commandLine.split(" ", 2);
		String subcommand = subcommandRest[0];
		if (subcommand.equals("project")) {
			addProject(subcommandRest[1]);
		} else if (subcommand.equals("task")) {
			boolean flag = subcommandRest[1].contains(",");
			String[] projectTask;
			if (!flag) {
				projectTask = subcommandRest[1].split(" ", 2);
				addTask(projectTask[0], projectTask[1]);
			} else {
				projectTask = subcommandRest[1].split(" ", 2);
				String data[] = projectTask[1].split(",");
				if (InputValidator.validateInput(data[1])) {
					taskList.getOut().printf(
							"This ID is not allowed \"%s\", ID should not coatin any special characters or spaces.",
							data[1]);
				} else if (checkUniqueId(data[1])) {
					addTask(projectTask[0], data[0].trim(), data[1].trim());
				} else {
					taskList.getOut().printf("This ID \"%s\".,already exists.", data[1]);
				}
			}

		}

	}

	private void addProject(String name) {
		taskList.getTasks().put(name, new ArrayList<Task>());
	}

	private void addTask(String project, String description, String id) {
		List<Task> projectTasks = taskList.getTasks().get(project);
		if (projectTasks == null) {
			taskList.getOut().printf("Could not find a project with the name \"%s\".", project);
			taskList.getOut().println();
			return;
		}
		projectTasks.add(new Task(id, description, false));
	}

	private void addTask(String project, String description) {
		List<Task> projectTasks = taskList.getTasks().get(project);
		if (projectTasks == null) {
			taskList.getOut().printf("Could not find a project with the name \"%s\".", project);
			taskList.getOut().println();
			return;
		}
		projectTasks.add(new Task(nextId(), description, false));
	}

	private String nextId() {
		taskList.getLastId().incrementAndGet();
		return taskList.getLastId().toString();
	}

	// check whether this id already present or not
	private boolean checkUniqueId(String id) {
		for (Map.Entry<String, List<Task>> project : taskList.getTasks().entrySet()) {
			for (Task task : project.getValue()) {
				if (task.getId().equals(id)) {
					return false;
				}
			}
		}
		return true;
	}
}
