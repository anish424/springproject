package com.employee.employee.service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.employee.entity.Employee;
import com.employee.employee.respository.EmployeeRespository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRespository employeeRepo;

	@Override
	public void saveEmployee(String data) {
		List<String> failedToSave = new ArrayList<>();
		String employeeData[] = data.split(System.lineSeparator());
		List<Employee> employeeList = Arrays.asList(employeeData).stream().map(s -> {
			try {
				return mapToEmployee(s);
			} catch (ParseException e) {
				log.error("Failed to parse joining date");
				failedToSave.add(s);
				return null;
			}
		}).collect(Collectors.toList());

		if (!failedToSave.isEmpty())
			throw new RuntimeException("Failed to save Employees: " + failedToSave);

		employeeRepo.saveAll(employeeList);
	}

	private Employee mapToEmployee(String data) throws ParseException {
		String[] values = data.split(",");
		return Employee.builder().firstname(values[0]).lastname(values[1]).joiningDate(getDate(values[2])).build();

	}

	private Date getDate(String dateStr) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		return new Date(formatter.parse(dateStr).getTime());
	}

}
