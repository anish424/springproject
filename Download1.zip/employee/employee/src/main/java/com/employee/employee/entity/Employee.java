package com.employee.employee.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Builder;

@Entity
@Builder
public class Employee {
	
	@Id
	private Integer id;
	
	@Column(name="EMPLOYEE_FIRST_NAME")
	private String firstname;
	
	@Column(name="EMPLOYEE_LAST_NAME")
	private String lastname;
	
	@Column(name="EMPLOYEE_JAINING_DATE")
	private Date joiningDate;

}
