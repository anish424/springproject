package com.employee.employee.service;

public interface EmployeeService {

	public void saveEmployee(String data);
}
