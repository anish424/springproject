package com.employee.employee.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.employee.employee.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService empService;

	@PostMapping("/employee")
	public ResponseEntity<String> saveEmployee(@RequestParam MultipartFile file) throws IOException {
		String data = new String(file.getBytes());

		empService.saveEmployee(data);
		return ResponseEntity.ok().body("");
	}

}
